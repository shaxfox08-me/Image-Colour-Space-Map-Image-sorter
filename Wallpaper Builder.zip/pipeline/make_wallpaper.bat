@echo off
REM Drag an image file onto this .bat to build a wallpaper from it.
if "%~1"=="" (
  echo Drag an image onto this file, or run:  make_wallpaper.bat image.png
  pause
  exit /b
)
python "%~dp0make_wallpaper.py" "%~1"
pause
