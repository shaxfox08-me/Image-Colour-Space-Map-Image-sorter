#!/usr/bin/env python3
"""
Turn a big image (e.g. a colour-map mosaic) into an interactive
Wallpaper Engine "web" wallpaper: tiled deep-zoom pyramid + pan/zoom viewer.

Usage:
    python make_wallpaper.py my_mosaic.png
    python make_wallpaper.py my_mosaic.png --name my-wallpaper --quality 90 --no-zip

Requires:  pip install pillow
"""
import argparse, math, os, shutil, sys, zipfile
from PIL import Image

Image.MAX_IMAGE_PIXELS = None  # allow very large mosaics

TILE = 256
OVERLAP = 1
HERE = os.path.dirname(os.path.abspath(__file__))
TEMPLATE = os.path.join(HERE, "template")


def build_tiles(img, out_dir, quality):
    w, h = img.size
    max_level = math.ceil(math.log2(max(w, h)))
    files_dir = os.path.join(out_dir, "map_files")
    cur = img
    for level in range(max_level, -1, -1):
        lw, lh = cur.size
        ldir = os.path.join(files_dir, str(level))
        os.makedirs(ldir, exist_ok=True)
        cols, rows = math.ceil(lw / TILE), math.ceil(lh / TILE)
        for c in range(cols):
            for r in range(rows):
                x0 = c * TILE - (OVERLAP if c > 0 else 0)
                y0 = r * TILE - (OVERLAP if r > 0 else 0)
                x1 = min((c + 1) * TILE + OVERLAP, lw)
                y1 = min((r + 1) * TILE + OVERLAP, lh)
                cur.crop((x0, y0, x1, y1)).save(
                    os.path.join(ldir, f"{c}_{r}.jpg"), quality=quality)
        print(f"  level {level:2d}: {lw}x{lh} ({cols * rows} tiles)")
        if level > 0:
            cur = cur.resize((max(1, math.ceil(lw / 2)), max(1, math.ceil(lh / 2))),
                             Image.LANCZOS)
    with open(os.path.join(out_dir, "map.dzi"), "w") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n'
                '<Image xmlns="http://schemas.microsoft.com/deepzoom/2008"\n'
                f'  Format="jpg" Overlap="{OVERLAP}" TileSize="{TILE}">\n'
                f'  <Size Width="{w}" Height="{h}"/>\n</Image>\n')


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("image")
    ap.add_argument("--name", help="output folder name (default: image name)")
    ap.add_argument("--quality", type=int, default=90, help="JPEG tile quality")
    ap.add_argument("--out", default=None, help="where to put the output folder (default: next to the image)")
    ap.add_argument("--no-zip", action="store_true")
    a = ap.parse_args()

    a.image = a.image.strip('"')
    out_root = (a.out.strip('"') if a.out else os.path.dirname(os.path.abspath(a.image)))
    name = a.name or os.path.splitext(os.path.basename(a.image))[0] + "-wallpaper"
    out = os.path.join(out_root, name)
    if os.path.exists(out):
        shutil.rmtree(out)
    os.makedirs(os.path.join(out, "tiles"))

    img = Image.open(a.image)
    print(f"Loaded {a.image}: {img.size[0]}x{img.size[1]} {img.mode}")
    if img.mode in ("RGBA", "LA", "P"):
        img = img.convert("RGBA")
        bg = (8, 8, 18)
        flat = Image.new("RGB", img.size, bg)
        flat.paste(img, mask=img.split()[-1])
        img = flat
    else:
        img = img.convert("RGB")

    bg = img.getpixel((0, 0))                 # background = top-left pixel
    bg_hex = "#%02x%02x%02x" % bg
    print(f"Background colour: {bg_hex}")

    print("Building tiles...")
    build_tiles(img, os.path.join(out, "tiles"), a.quality)

    shutil.copytree(os.path.join(TEMPLATE, "lib"), os.path.join(out, "lib"))
    with open(os.path.join(TEMPLATE, "index.html"), encoding="utf-8") as f:
        html = f.read().replace("{{BG}}", bg_hex)
    with open(os.path.join(out, "index.html"), "w", encoding="utf-8") as f:
        f.write(html)

    if not a.no_zip:
        zpath = out + ".zip"
        with zipfile.ZipFile(zpath, "w", zipfile.ZIP_DEFLATED) as z:
            for root, _, files in os.walk(out):
                for fn in files:
                    full = os.path.join(root, fn)
                    z.write(full, os.path.relpath(full, os.path.dirname(out)))
        print(f"Zipped: {zpath}")
    print(f"Done -> {out}\nIn Wallpaper Engine, add the wallpaper by selecting {out}{os.sep}index.html")


if __name__ == "__main__":
    sys.exit(main())
