COLOUR MAP WALLPAPER BUILDER (no AI needed)

One-time setup:
  1. Install Python 3 from python.org (tick "Add to PATH")
  2. Open a terminal and run:  pip install pillow

Build a wallpaper:
  - Drag your mosaic PNG onto make_wallpaper.bat
    (or: python make_wallpaper.py mosaic.png)
  - You get a folder + zip next to your image.
  - In Wallpaper Engine, add the wallpaper by selecting the folder's index.html.

Tweaking the viewer (idle drift speed, zoom step, button style):
  edit template/index.html - everything is plain commented JS/CSS.
  {{BG}} is replaced automatically with the image's background colour.
